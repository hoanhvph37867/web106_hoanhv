package com.example.myapplication.ThiThu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import com.example.myapplication.R;
import com.example.myapplication.demo5.Demo52ListviewAdapter;
import com.example.myapplication.demo5.demo51MainActivity;

import java.util.ArrayList;

public class DanhSachMainActivity extends AppCompatActivity {
    ListView listView;
    Button btn;
    Toolbar toolbar;
    Demo52ListviewAdapter adapter;
    SearchView searchView;
    private com.example.myapplication.ThiThu.Adapter Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_main);
        listView=findViewById(R.id.demoListview);
        btn=findViewById(R.id.demoBtn);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        // tao du lieu
        ArrayList<HoaQua> list = new ArrayList<>();
        list.add(new HoaQua("CS Ha Noi","Nguyen Van A", "100.000"));
        list.add(new HoaQua("CS HCM","Tran Van B", "110.000"));
        list.add(new HoaQua("CS Ha Nam","Hoang Van C", "80.000"));
        list.add(new HoaQua("CS Tay Nguyen","Hoang Thi D", "20.000"));
        Adapter= new Adapter(this,list);
        listView.setAdapter(adapter);
        //cai dạt activity for result
        ActivityResultLauncher<Intent> getData = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode()==2){
                            Intent intent=result.getData();//lay ve du lieu
                            Bundle bundle= intent.getExtras();// lay ve goi
                            String branch= bundle.getString("MaHoaQua");
                            String name= bundle.getString("TenHoaQua");
                            String address= bundle.getString("DonGia");
                            list.add(new HoaQua(branch,name,address));
                            adapter.notifyDataSetChanged();
                        }
                    }

                }
        );
        // xu ly du lieu
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(DanhSachMainActivity.this, demo51MainActivity.class);
                getData.launch(intent);
            }
        });
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}