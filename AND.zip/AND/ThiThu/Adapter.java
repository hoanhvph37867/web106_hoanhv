package com.example.myapplication.ThiThu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class Adapter extends BaseAdapter implements Filterable {
    private Context context;
    private ArrayList<HoaQua> list,listOld;

    public Adapter(Context context, ArrayList<HoaQua> list) {
        this.context = context;
        this.listOld=list;
        this.list = list;
    }

    public Adapter(String maHoaQua, String tenHoaQua, String donGia) {
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ///1. tao layout va lien ket layout
        LayoutInflater inflater=((Activity)context).getLayoutInflater();
        convertView=inflater.inflate(R.layout.listview_item_demo52,parent,false);
        //2. anh xa tung thanh phan cua layout
        TextView tvCoSo= convertView.findViewById(R.id.demo_item_TvCoSo);
        TextView tvHoTen= convertView.findViewById(R.id.demo_item_TvHoTen);
        TextView tvDiaChi= convertView.findViewById(R.id.demo_item_TvDiaChi);
        Button btnDelete=convertView.findViewById(R.id.demo52BtnDelete);
        Button btnUpdate=convertView.findViewById(R.id.demo52BtnUpdate);
        //3. dien du lieu
        tvCoSo.setText(list.get(position).getBranch());
        tvHoTen.setText(list.get(position).getName());
        tvDiaChi.setText(list.get(position).getAddress());
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list.remove(position);
                notifyDataSetChanged();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //tao 1 layout hien thi
                //tao dialog de gan voi layout
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                //--thanh lap dialog
                //b1-Tao layout
                LayoutInflater inflater1=((Activity) context).getLayoutInflater();
                View view1=inflater1.inflate(R.layout.dialog_bai54,null);
                builder.setView(view1);
                //b2-anh xa
                final EditText txtCoSo=view1.findViewById(R.id.demo55Txt1);
                final EditText txtTen=view1.findViewById(R.id.demo55Txt2);
                final EditText txtDiaChi=view1.findViewById(R.id.demo55Txt3);
                //b3-set tieu de
                builder.setTitle("update form");
                //b4. xu ly button cap nhat
                builder.setPositiveButton("Cap nhat", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //lay ve du lieu nhap vao dialog
                        String coso=txtCoSo.getText().toString();
                        String ten=txtTen.getText().toString();
                        String diachi=txtDiaChi.getText().toString();
                        //cap nhat vao list
                        list.get(position).setAddress(diachi);
                        list.get(position).setName(ten);
                        list.get(position).setBranch(coso);
                    }
                });
                //--
                AlertDialog alertDialog=builder.create();
                alertDialog.show();
            }
        });

        return convertView;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String s = constraint.toString();
                if (s.isEmpty()) {
                    list = listOld;
                } else {
                    ArrayList<HoaQua> listS = new ArrayList<>();
                    for (HoaQua st : listOld) {
                        if (st.getName().toLowerCase().contains(s.toLowerCase())) {
                            listS.add(st);
                        }
                    }
                    list = listS;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = list;
                return filterResults;
            }


            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                list = (ArrayList<HoaQua>) results.values;
                notifyDataSetChanged();
            }
        };

    }
}
