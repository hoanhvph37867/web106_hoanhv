package com.example.myapplication.ThiThu;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class StartMainActivity extends AppCompatActivity {
    ImageView imageView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_main);
        imageView=findViewById(R.id.demoImg1);
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.demothitu);
        imageView.startAnimation(animation);
        //chuyen sau 5s
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(StartMainActivity.this, DanhSachMainActivity.class);
                startActivity(intent);
                finish();
            }
        },5000);
    }

}